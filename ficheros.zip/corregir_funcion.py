import json
import tkinter.messagebox as messagebox
from thonny import get_workbench


def cargar_tests():
    """Carga los tests desde tests.json (solo lectura)"""
    import os
    base_dir = os.path.dirname(__file__)
    ruta_tests = os.path.join(base_dir, "tests.json")
    try:
        with open(ruta_tests, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        messagebox.showerror("Error", f"No se pudieron cargar los tests:\n{e}")
        return {}


def corregir_funcion():
    """Evalúa la función actual directamente desde el editor (sin escribir en disco)"""
    editor = get_workbench().get_editor_notebook().get_current_editor()
    if not editor:
        messagebox.showerror("Error", "No hay un archivo abierto.")
        return

    # Obtener el código actual del editor
    codigo = editor.get_text_widget().get("1.0", "end-1c").strip()
    if not codigo:
        messagebox.showerror("Error", "El archivo está vacío.")
        return

    # La primera línea debe indicar la función a evaluar
    primera_linea = codigo.splitlines()[0].strip()
    if not primera_linea.startswith("#"):
        messagebox.showerror("Error", "La primera línea debe contener el nombre de la función como comentario.")
        return

    nombre_funcion = primera_linea[1:].strip()
    tests = cargar_tests()

    if nombre_funcion not in tests:
        messagebox.showwarning("Aviso", f"No hay tests definidos para la función '{nombre_funcion}'.")
        return

    # Ejecutar el código del alumno en un espacio aislado
    entorno = {}
    try:
        exec(codigo, entorno)
    except Exception as e:
        messagebox.showerror("Error al ejecutar el código del alumno", str(e))
        return

    # Obtener la función definida
    funcion = entorno.get(nombre_funcion)
    if not callable(funcion):
        messagebox.showerror("Error", f"No se encontró la función '{nombre_funcion}'.")
        return

    # Ejecutar los tests
    fallos = []
    for caso in tests[nombre_funcion]:
        args = caso.get("args", [])
        esperado = caso.get("expected", None)
        try:
            resultado = funcion(*args)
            if resultado != esperado:
                fallos.append(f"{args} → esperado {esperado}, obtuvo {resultado}")
        except Exception as e:
            fallos.append(f"{args} → error: {e}")

    # Mostrar resultados
    if not fallos:
        messagebox.showinfo("Éxito", f"La función '{nombre_funcion}' pasa todos los tests ✅")
    else:
        detalles = "\n".join(fallos)
        messagebox.showerror("Fallos en tests", f"Algunos tests fallaron:\n{detalles}")


def cargar_plugin():
    """Añade el comando al menú Herramientas"""
    get_workbench().add_command(
        command_id="corregir_funcion",
        menu_name="tools",  # menú "Herramientas"
        command_label="Corregir función del alumno",
        handler=corregir_funcion
    )
    # Añadir atajo F10 de forma segura
    wb.set_default_key_binding("<Alt-F10>", "corregir_funcion")


print("✅ Plugin 'corregir_funcion' cargado correctamente (sin escritura en disco)")
cargar_plugin()
