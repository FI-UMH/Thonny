#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 18 18:12:15 2025

@author: al3jandro
"""

from qtpy.QtWidgets import QAction
from spyder.app.start import main

def add_button():
    app = main()
    action = QAction("Mostrar fuente activo", app)
    
    def mostrar_fuente():
        editor = app.editor
        current_file = editor.get_current_filename()
        if not current_file:
            print("No hay archivo activo")
            return
        with open(current_file, "r", encoding="utf-8") as f:
            codigo = f.read()
        # Mostrar en la consola de Spyder
        app.ipyconsole.write_to_stdin(f"print('''{codigo}''')\n")

    action.triggered.connect(mostrar_fuente)
    app.menuBar().addAction(action)

add_button()
