#!/bin/bash
RCLONE_OPTS="
  --vfs-cache-mode=full
  --cache-dir=/tmp/rclone_cache
  --attr-timeout=24h 
  --vfs-cache-max-size=32G
  --vfs-cache-max-age=24h
  --vfs-read-chunk-size=64M
  --vfs-read-chunk-size-limit=2G
  --buffer-size=2G
  --max-read-ahead=1G
  --dir-cache-time=5m
  --poll-interval=0s
  --timeout=5m
  --allow-other
  --transfers=32
  --checkers=16
  --log-level=ERROR
  --umask 007
  --uid=$(id -u)
  --gid=$(id -g)
"
RCLONE_OPTS_ONEDRIVE="
  --vfs-cache-mode=full
  --cache-dir=/tmp/rclone_onedrive_cache
  --vfs-cache-max-size=32G
  --attr-timeout=24h 
  --vfs-cache-max-age=72h
  --vfs-read-chunk-size=64M
  --vfs-read-chunk-size-limit=512M
  --buffer-size=2G
  --max-read-ahead=1G
  --dir-cache-time=5m
  --poll-interval=0s
  --timeout=5m
  --transfers=4
  --checkers=4
  --umask=000
  --uid=1000
  --gid=1000
  --allow-other "
/bin/rclone mount pomares:/ 		/mnt/pomares 				--rc --rc-addr=127.0.0.1:5570	$RCLONE_OPTS &
/bin/rclone mount fi:/ 			/mnt/fi 				--rc --rc-addr=127.0.0.1:5571	$RCLONE_OPTS &
/bin/rclone mount dic:/ 		/mnt/dic 				--rc --rc-addr=127.0.0.1:5572	$RCLONE_OPTS &
/bin/rclone mount pomares.alejandro:/ 	/mnt/pomares.alejandro 			--rc --rc-addr=127.0.0.1:5573	$RCLONE_OPTS &
/bin/rclone mount digi:/ 		/mnt/digi 				--rc --rc-addr=127.0.0.1:5574	$RCLONE_OPTS &
/bin/rclone mount onedrive:/ 		/mnt/onedrive 				--rc --rc-addr=127.0.0.1:5575	$RCLONE_OPTS_ONEDRIVE &
/bin/rclone mount hymer:/ 		/mnt/hymer 				--rc --rc-addr=127.0.0.1:5576	$RCLONE_OPTS &
/bin/rclone mount web:/ 		/mnt/web 				--rc --rc-addr=127.0.0.1:5577	$RCLONE_OPTS &
/bin/rclone mount ochoa:/ 		/mnt/ochoa 				--rc --rc-addr=127.0.0.1:5578	$RCLONE_OPTS &
/bin/rclone mount umh:/ 		/mnt/umh 				--rc --rc-addr=127.0.0.1:5579	$RCLONE_OPTS &
/bin/rclone mount pm:/ 			/mnt/pm 				--rc --rc-addr=127.0.0.1:5580	$RCLONE_OPTS &
/bin/rclone mount corrector-alumno:/home/alumno /mnt/corrector-alumno           --rc --rc-addr=127.0.0.1:5581   $RCLONE_OPTS &
/bin/rclone mount corrector-pomares:/home/pomares /mnt/corrector-pomares        --rc --rc-addr=127.0.0.1:5582   $RCLONE_OPTS &
